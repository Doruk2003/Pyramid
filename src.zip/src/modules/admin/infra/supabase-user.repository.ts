import { supabase } from '@/lib/supabase';
import { User } from '@/modules/admin/domain/user.entity';
import type { IUserRepository } from '@/modules/admin/domain/user.repository';
import { ok, err, type Result } from '@/shared/types/result';
import type { DbUser } from '@/shared/infra/db-types';

export class SupabaseUserRepository implements IUserRepository {
  async getById(id: string): Promise<Result<User>> {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', id)
      .single();

    if (error) return err(new Error(error.message));
    if (!data) return err(new Error('User not found'));

    return ok(this.mapToEntity(data as DbUser));
  }

  async getByEmail(email: string): Promise<Result<User>> {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('email', email)
      .single();

    if (error) return err(new Error(error.message));
    if (!data) return err(new Error('User not found'));

    return ok(this.mapToEntity(data as DbUser));
  }

  async save(user: User): Promise<Result<void>> {
    const { error } = await supabase
      .from('users')
      .upsert({
        id: user.id,
        company_id: user.companyId,
        email: user.email,
        full_name: user.fullName,
        role: user.role,
        is_active: user.isActive,
        created_at: user.createdAt
      });

    if (error) return err(new Error(error.message));
    return ok(undefined);
  }

  async delete(id: string): Promise<Result<void>> {
    const { error } = await supabase
      .from('users')
      .delete()
      .eq('id', id);

    if (error) return err(new Error(error.message));
    return ok(undefined);
  }

  async list(): Promise<Result<User[]>> {
    const { data, error } = await supabase
      .from('users')
      .select('*');

    if (error) return err(new Error(error.message));
    return ok((data as DbUser[] || []).map(row => this.mapToEntity(row)));
  }

  private mapToEntity(row: DbUser): User {
    return User.create({
      id: row.id,
      companyId: row.company_id,
      email: row.email,
      fullName: row.full_name,
      role: row.role,
      isActive: row.is_active,
      createdAt: new Date(row.created_at)
    });
  }
}



