import type { IUserRepository } from '@/modules/admin/domain/user.repository';
import type { User } from '@/modules/admin/domain/user.entity';
import type { Result } from '@/shared/types/result';

export class SaveUserUseCase {
  constructor(private userRepository: IUserRepository) {}

  async execute(user: User): Promise<Result<void>> {
    return this.userRepository.save(user);
  }
}


