import { defineStore } from 'pinia';
import type { User } from '@/modules/admin/domain/user.entity';
import { SupabaseUserRepository } from '@/modules/admin/infra/supabase-user.repository';
import { ListUsersUseCase } from '@/modules/admin/application/list-users.usecase';
import { SaveUserUseCase } from '@/modules/admin/application/save-user.usecase';
import { DeleteUserUseCase } from '@/modules/admin/application/delete-user.usecase';

const userRepository = new SupabaseUserRepository();
const listUsersUseCase = new ListUsersUseCase(userRepository);
const saveUserUseCase = new SaveUserUseCase(userRepository);
const deleteUserUseCase = new DeleteUserUseCase(userRepository);

export const useUserStore = defineStore('user', {
  state: () => ({
    users: [] as User[],
    loading: false,
    error: null as string | null
  }),

  actions: {
    async fetchUsers() {
      this.loading = true;
      const result = await listUsersUseCase.execute();
      if (result.success) {
        this.users = result.data;
      } else {
        this.error = (result as any).error.message;
      }
      this.loading = false;
    },

    async saveUser(user: User) {
      this.loading = true;
      const result = await saveUserUseCase.execute(user);
      if (result.success) {
        await this.fetchUsers();
      } else {
        this.error = (result as any).error.message;
      }
      this.loading = false;
      return result;
    },

    async deleteUser(id: string) {
      this.loading = true;
      const result = await deleteUserUseCase.execute(id);
      if (result.success) {
        await this.fetchUsers();
      } else {
        this.error = (result as any).error.message;
      }
      this.loading = false;
      return result;
    }
  }
});



