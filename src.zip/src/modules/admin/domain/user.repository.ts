import type { User } from '@/modules/admin/domain/user.entity';
import type { Result } from '@/shared/types/result';

export interface IUserRepository {
  getById(id: string): Promise<Result<User>>;
  getByEmail(email: string): Promise<Result<User>>;
  save(user: User): Promise<Result<void>>;
  delete(id: string): Promise<Result<void>>;
  list(): Promise<Result<User[]>>;
}


